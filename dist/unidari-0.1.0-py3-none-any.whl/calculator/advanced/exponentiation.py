def power(a, b):
    return a ** b
if __name__ == "__main__":
    print(power(2, 5))
    print("йоу")
else: print ("не йоу")