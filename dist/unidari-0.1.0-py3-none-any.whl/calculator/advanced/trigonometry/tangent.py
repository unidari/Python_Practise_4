import math
def tan(x): return math.tan(x)