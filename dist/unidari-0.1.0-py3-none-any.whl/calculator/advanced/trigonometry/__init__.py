from .sine import sin
from .cosine import cos
from .tangent import tan
