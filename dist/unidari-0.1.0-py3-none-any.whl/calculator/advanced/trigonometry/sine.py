import math
#from calculator.advanced.root import square_root
#from ..advanced.root import square_root
def sin(x): return math.sin(x)
