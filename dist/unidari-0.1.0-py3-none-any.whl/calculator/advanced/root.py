def square_root(a):
    return a ** 0.5