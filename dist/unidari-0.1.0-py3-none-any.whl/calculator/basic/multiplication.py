def multiply (a, b):
    return a*b