from calculator.basic.addition import add
from calculator.basic.subtraction import subtract
from calculator.basic.multiplication import multiply